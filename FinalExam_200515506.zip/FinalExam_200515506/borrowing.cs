using System;
using System.Security.Cryptography.X509Certificates;
public class borrowing:resource , Idownloadable
{
    public int ReferenceNumber;
    public string UserId="";
    public DateTime StartDate = Convert.ToDateTime("19/04/2023");
    public DateTime EndDate = Convert.ToDateTime("29/04/2023");
    public bool PickedUp;
    
    public List<resource>Resources = new List<resource>();


    public borrowing(string UserId, List<resource> resources)
    {
        this.UserId = UserId;
        this.Resources = resources;
    }

    public void ReturnResources(DateTime Date)
    {
        if(Date > EndDate)
        {
            Console.WriteLine("The FINE Must Be Paid by You"); 
        }

        if (Date < EndDate)
        {
            Console.WriteLine("Thank you");
        }

        PickedUp = true;

    }

    string Idownloadable.GenerateAccessLink()
    {
        return "CCCCCCC";
    }
}