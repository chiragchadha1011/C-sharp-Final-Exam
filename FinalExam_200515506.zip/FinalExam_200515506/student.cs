public class student:User
{
    public int StudentID;
    public string SchoolCardNumber="";
    private DateTime BirthDate;
}