public class standard:User
{
    public string PostCode="";
    public string LibraryCardNumber="";
    private string CreditCardNumber="";
}