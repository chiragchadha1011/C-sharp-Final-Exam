﻿namespace FinalExam_200515506;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("FINALEXAM-200515506");
        student students = new student();
        students.FirstName = "CHIRAG";
        students.LastName = "CHADHA";
        students.Address = "472 Ford Street";
        students.PhoneNumber = "647-533-5343";

        resource Resources = new resource();
        Resources.Code = "https://www.worldcat.org/title/1195447665";
        Resources.Title = "Gulliver's Travels";
        Resources.Description = "The Best Adventerous Book ";
        Resources.Publisher = "Adam Matthew Digital, Wrigley, James, Marlborough, Wiltshire, New York, 2020";
        Resources.DatePublished = Convert.ToDateTime("23/12/1860");

        resource resources1 = new resource();
        resources1.Code = "https://www.worldcat.org/title/1002128968";
        resources1.Title = "Chetan Bhagat : the icon of popular fiction";
        resources1.Description = "This book is an assessment of the critical role of Indian greatest author in book industry";
        resources1.Publisher = "Prestige Books International, Delhi, 2014";
        resources1.DatePublished = Convert.ToDateTime("02/07/2014");

        List<resource> resources = new List<resource>();
        borrowing borrow= new borrowing("ARROW10", resources);
        borrow.StartDate = Convert.ToDateTime("07/11/2014");
        borrow.EndDate = Convert.ToDateTime("19/02/2016");
        
    }
}
