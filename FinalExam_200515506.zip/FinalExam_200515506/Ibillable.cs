public interface IBillable //:standard
{
   public bool ProcessPayment()
    {
        return true;
    } 
}