﻿using System;

namespace GeographyQuiz
{
    class Program
    {
        static void Main(string[] args)
        {
            Quiz quizGame = new Quiz();
            quizGame.quiz();
        }
    }
}