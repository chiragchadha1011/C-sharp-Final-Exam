using System;

namespace GeographyQuiz
{
    public class Quiz
    {
        public void quiz()
        {
            Console.WriteLine("\nNamaste! Welcome to the Geography Quiz my friend");
            Console.WriteLine("\nThis quiz will test your knowledge of countries, capitals, landmarks, and more.");
            Console.WriteLine("\nSo let's get Started!!!!!!\n\n");

            // Arrays to store the questions, options, and answers
            string[] questions = {
                "What is the largest country by area in South America?",
                "What is the capital of Denmark?",
                "Which is the smallest country in the world?",
                "How many states does USA have?",
                "The Eiffel Tower can be found in which European capital city?",
                "The Statue of Liberty was a gift to America from which country?",
                "What is the highest waterfall in the world?",
                "What is the northernmost country in the world?",
                "What is the largest country by area in Africa?",
                "How many land borders does India have?"
            };

            string[,] options = {
                {"A) Brazil", "B) Argentina", "C) Peru", "D) Chile"},
                {"A) Helsinki", "B) Copenhagen", "C) Oslo", "D) Warsaw"},
                {"A) Vatican City", "B) Andorra", "C) San-Marino", "D) Lesotho"},
                {"A) 49", "B) 50", "C) 48", "D) 51"},
                {"A) London", "B) Madrid", "C) Lisbon", "D) Paris"},
                {"A) Spain", "B) Portugal", "C) France", "D) England"},
                {"A) Niagara Falls", "B) Angel Falls", "C) Victoria Falls", "D) Iguazu Falls"},
                {"A) Norway", "B) Sweden", "C) Finland", "D) Iceland"},
                {"A) Algeria", "B) Sudan", "C) South Africa", "D) Kenya"},
                {"A) 7", "B) 4", "C) 6", "D) 5"}
            };

            string[] answers = {"A", "B", "A", "B", "D", "C", "B", "D", "A", "A"};

            int score = 0;
            bool repeat = false;

            do
            {
                for (int i = 0; i < questions.Length; i++)
                {
                    Console.WriteLine("Question " + (i + 1) + ": " + questions[i]);
                    Console.WriteLine(options[i, 0]);
                    Console.WriteLine(options[i, 1]);
                    Console.WriteLine(options[i, 2]);
                    Console.WriteLine(options[i, 3]);
                    Console.WriteLine("Type your Answer below : ");
                    string answer = Console.ReadLine();

                    switch(answer.ToLower())
                    {
                        case "a":
                        case "b":
                        case "c":
                        case "d":
                            if (answer.ToLower() == answers[i].ToLower())
                            {
                                Console.WriteLine("------------------------------------\nYay! The answer is Correct!\n------------------------------------");
                                score += 10;
                            }
                            else
                            {
                                Console.WriteLine("-------------------------------------\nOh no! This answer is Incorrect.\n-------------------------------------");
                            }
                            break;
                        default:
                            Console.WriteLine("Invalid input. Please enter A, B, C, or D.");
                            break;
                    }
                }

                Console.WriteLine("\nYour final score is " + score + "/100.");

                if (score == 100)
                {
                    Console.WriteLine("Congratulations! You got a perfect score!");
                }
                else if (score >= 70)
                {
                    Console.WriteLine("Great job! You passed the quiz.");
                }
                else
                {
                    Console.WriteLine("Sorry, you didn't pass the quiz.");
                }
                Console.WriteLine("\n\n-----------------------------------------");
                Console.Write("Would you like to play again? (Y/N): \n");
                Console.WriteLine("-----------------------------------------");
                string playAgain = Console.ReadLine();
            
                if (playAgain.ToLower() == "y")
                {
                    repeat = true;
                    score = 0;
                }

                else if(playAgain.ToLower() == "n")
                {
                    Console.WriteLine("Thank you for playing.");
                    break;
                }

                else
                {
                    Console.WriteLine("Invalid Input.");
                    break;
                }

            }while(repeat==true);
        }
    }
}
